package com.gameturbo.app

import android.annotation.SuppressLint
import android.app.AppOpsManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        web = WebView(this)
        web.setBackgroundColor(0xFF04060D.toInt())
        web.overScrollMode = View.OVER_SCROLL_NEVER
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onResume() {
        super.onResume()
        web.evaluateJavascript("window.onNativeResume && window.onNativeResume()", null)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // jangan tutup app dari tombol kembali; cukup ke layar utama
        moveTaskToBack(true)
    }

    // ---------- izin ----------
    private fun hasUsage(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        val m = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        return m == AppOpsManager.MODE_ALLOWED
    }

    private fun startSetting(action: String, withPkg: Boolean) {
        runOnUiThread {
            try {
                val i = Intent(action)
                if (withPkg) i.data = Uri.parse("package:$packageName")
                startActivity(i)
            } catch (e: Exception) {
                try {
                    startActivity(Intent(Settings.ACTION_SETTINGS))
                } catch (_: Exception) {
                }
            }
        }
    }

    inner class Bridge {

        @JavascriptInterface
        fun getGames(): String {
            val arr = JSONArray()
            Games.load(this@MainActivity).forEach { g ->
                arr.put(JSONObject().put("id", g.pkg).put("n", g.label).put("p", g.pkg).put("i", Games.iconB64(g.icon)))
            }
            return arr.toString()
        }

        @JavascriptInterface
        fun getApps(): String {
            val shown = Games.gamePackages(this@MainActivity)
            val arr = JSONArray()
            Games.launchable(this@MainActivity).forEach { (p, n) ->
                arr.put(JSONObject().put("p", p).put("n", n).put("g", p in shown))
            }
            return arr.toString()
        }

        @JavascriptInterface
        fun addGame(pkg: String) { Games.addManual(this@MainActivity, pkg) }

        @JavascriptInterface
        fun hideGame(pkg: String) { Games.hide(this@MainActivity, pkg) }

        @JavascriptInterface
        fun stats(): String {
            val mi = Booster.memInfo(this@MainActivity)
            return JSONObject()
                .put("ram", Booster.ramPercent(this@MainActivity))
                .put("usedMb", (mi.totalMem - mi.availMem) / 1048576L)
                .put("totalMb", mi.totalMem / 1048576L)
                .put("bat", Booster.batteryPercent(this@MainActivity))
                .put("temp", Booster.batteryTempC(this@MainActivity)?.toDouble() ?: -1.0)
                .toString()
        }

        /** Tutup proses background app lain. Return jumlah app yang diproses. */
        @JavascriptInterface
        fun boost(keep: String): Int =
            Booster.boost(this@MainActivity, if (keep.isEmpty()) emptySet() else setOf(keep))

        @JavascriptInterface
        fun launch(pkg: String): Boolean {
            val intent = packageManager.getLaunchIntentForPackage(pkg) ?: return false
            if (Settings.canDrawOverlays(this@MainActivity)) {
                OverlayService.start(this@MainActivity, pkg)
            }
            runOnUiThread { startActivity(intent) }
            return true
        }

        @JavascriptInterface
        fun perms(): String = JSONObject()
            .put("overlay", Settings.canDrawOverlays(this@MainActivity))
            .put("usage", hasUsage())
            .put("dnd", (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).isNotificationPolicyAccessGranted)
            .put("write", Settings.System.canWrite(this@MainActivity))
            .put("running", OverlayService.running)
            .toString()

        @JavascriptInterface
        fun openPerm(which: String) {
            when (which) {
                "overlay" -> startSetting(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, true)
                "usage" -> startSetting(Settings.ACTION_USAGE_ACCESS_SETTINGS, false)
                "dnd" -> startSetting(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS, false)
                "write" -> startSetting(Settings.ACTION_MANAGE_WRITE_SETTINGS, true)
            }
        }

        @JavascriptInterface
        fun overlay(on: Boolean): Boolean {
            if (!on) { OverlayService.stop(this@MainActivity); return true }
            if (!Settings.canDrawOverlays(this@MainActivity)) return false
            OverlayService.start(this@MainActivity, null)
            return true
        }

        @JavascriptInterface
        fun openSetting(action: String) { startSetting(action, false) }
    }
}
